#pragma once

#define BLEMIDI_NAMESPACE                  bleMidi
#define BEGIN_BLEMIDI_NAMESPACE            namespace BLEMIDI_NAMESPACE {
#define END_BLEMIDI_NAMESPACE              }

#define USING_NAMESPACE_BLEMIDI            using namespace BLEMIDI_NAMESPACE;

BEGIN_BLEMIDI_NAMESPACE

END_BLEMIDI_NAMESPACE
